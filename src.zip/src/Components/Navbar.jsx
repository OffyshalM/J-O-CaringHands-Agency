import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Briefcase } from 'lucide-react';
import logo from '../assets/jo-logo.jpeg';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100 font-sans transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center h-20">
          
          <Link to="/" className="flex items-center gap-3">
            <img src={logo} alt="Logo" className="h-12 md:h-14 w-auto object-contain" />
            {/* <div className="hidden sm:flex flex-col">
              <span className="text-lg font-black text-brand-dark uppercase leading-none">J & O CaringHands</span>
              <span className="text-[9px] font-bold text-brand-blue uppercase tracking-widest mt-1">Agency, LLC</span>
            </div> */}
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-sm font-bold text-brand-dark hover:text-brand-blue uppercase tracking-wide transition-colors">Home</a>
            <a href="#about" className="text-sm font-bold text-brand-dark hover:text-brand-blue uppercase tracking-wide transition-colors">About Us</a>
            <a href="#services" className="text-sm font-bold text-brand-dark hover:text-brand-blue uppercase tracking-wide transition-colors">Services</a>
            <a href="#faq" className="text-sm font-bold text-brand-dark hover:text-brand-blue uppercase tracking-wide transition-colors">FAQ</a>
            <a href="#contact" className="text-sm font-bold text-brand-dark hover:text-brand-blue uppercase tracking-wide transition-colors">Contact Us</a>
            
            <Link to="https://form.jotform.com/260637714154053" className="bg-brand-blue text-white px-5 py-2.5 rounded-full font-bold text-xs uppercase flex items-center gap-2 hover:bg-brand-dark transition-all shadow-md hover:shadow-lg active:scale-95">
              <Briefcase size={14} /> We're Hiring!
            </Link>
          </div>

          <div className="md:hidden">
            <button 
              onClick={() => setIsOpen(!isOpen)} 
              className="bg-brand-blue text-white p-2.5 shadow-md focus:outline-none flex items-center justify-center overflow-hidden rounded-none"
            >
              <div className={`transition-all duration-[1000ms] ease-in-out transform ${isOpen ? 'rotate-180 scale-110' : 'rotate-0 scale-100'}`}>
                {isOpen ? <X size={28} /> : <Menu size={28} />}
              </div>
            </button>
          </div>
        </div>
      </div>

      <div className={`md:hidden absolute w-full bg-brand-blue/95 backdrop-blur-lg transition-all duration-[800ms] ease-in-out ${isOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-10 pointer-events-none'}`}>
        <div className="flex flex-col p-6 space-y-2 shadow-2xl">
          <a href="#home" onClick={() => setIsOpen(false)} className="text-white font-medium text-lg py-4 border-b border-white/10 hover:pl-2 transition-all">Home</a>
          <a href="#about" onClick={() => setIsOpen(false)} className="text-white font-medium text-lg py-4 border-b border-white/10 hover:pl-2 transition-all">About Us</a>
          <a href="#services" onClick={() => setIsOpen(false)} className="text-white font-medium text-lg py-4 border-b border-white/10 hover:pl-2 transition-all">Services</a>
          <a href="#faq" onClick={() => setIsOpen(false)} className="text-white font-medium text-lg py-4 border-b border-white/10 hover:pl-2 transition-all">FAQ</a>
          <a href="#contact" onClick={() => setIsOpen(false)} className="text-white font-medium text-lg py-4 border-b border-white/10 hover:pl-2 transition-all">Contact Us</a>

          <Link to="https://form.jotform.com/260637714154053" onClick={() => setIsOpen(false)} className="bg-white text-brand-dark py-4 rounded-xl font-bold uppercase text-center flex items-center justify-center gap-3 mt-4 shadow-lg active:scale-95 transition-transform">
            <Briefcase size={20} className="text-brand-dark" /> We're Hiring!
          </Link>
        </div>
      </div>
    </nav>
  );
}