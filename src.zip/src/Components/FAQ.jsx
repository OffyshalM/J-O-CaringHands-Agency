import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(null);

  const faqs = [
    {
      question: "What areas do you serve?",
      answer: "We are licensed and proudly serve families in the following counties: Montgomery, Delaware, Philadelphia, Lehigh, Bucks, and Chester."
    },
    {
      question: "Are your caregivers background checked?",
      answer: "Yes, absolutely. Every caregiver at J & O CaringHands undergoes a background check , including criminal background checks, state regulations , and  interview to ensure they meet our standards of integrity and compassion."
    },
    {
      question: "Is your care available 24/7?",
      answer: "Yes. We provide care around the clock, including weekends and holidays. Whether you need a few hours a week or 24-hour live-in support, we are here for you."
    },
    {
      question: "Do you provide medical or nursing care?",
      answer: "J & O CaringHands Agency, LLC is a non-medical home care agency. We assist with activities of daily living (ADLs) such as bathing, meal prep, and companionship. We do not provide clinical nursing services like wound care or injections."
    },
    {
      question: "How do we get started?",
      answer: "Getting started is simple. Contact us for a free in-home assessment. We will discuss your needs, develop a custom care plan, and match you with a caregiver who fits your family's personality and requirements."
    }
  ];

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-16 md:py-24 bg-white font-sans">
      <div className="max-w-3xl mx-auto px-5 md:px-6">
        
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-brand-blue/10 text-brand-blue rounded-full mb-4">
            <HelpCircle size={24} />
          </div>
          <h2 className="text-3xl md:text-5xl font-black text-brand-dark mb-4 uppercase tracking-tighter">
            Common <span className="text-brand-blue">Questions</span>
          </h2>
          <p className="text-slate-500 text-sm md:text-base font-medium">
            Everything you need to know about our home care services.
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className={`border rounded-2xl transition-all duration-300 ${openIndex === index ? 'border-brand-blue shadow-lg shadow-sky-50' : 'border-slate-100 bg-slate-50'}`}
            >
              <button 
                onClick={() => toggleFAQ(index)}
                className="w-full flex items-center justify-between p-5 md:p-6 text-left focus:outline-none"
              >
                <span className={`text-sm md:text-base font-bold transition-colors ${openIndex === index ? 'text-brand-blue' : 'text-brand-dark'}`}>
                  {faq.question}
                </span>
                <ChevronDown 
                  size={20} 
                  className={`text-slate-400 transition-transform duration-500 ${openIndex === index ? 'rotate-180 text-brand-blue' : ''}`} 
                />
              </button>

              <div 
                className={`overflow-hidden transition-all duration-500 ease-in-out ${openIndex === index ? 'max-h-96' : 'max-h-0'}`}
              >
                <div className="p-5 md:p-6 pt-0 text-slate-600 text-sm md:text-base leading-relaxed border-t border-slate-100/50">
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center p-8 bg-brand-blue/5 rounded-3xl border border-brand-blue/10">
          <p className="text-sm font-bold text-brand-dark">
            Still have questions? 
            <a href="#contact" className="text-brand-blue underline ml-2 hover:text-brand-blue-dark">Reach out to us directly.</a>
          </p>
        </div>

      </div>
    </section>
  );
}