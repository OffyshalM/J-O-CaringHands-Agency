import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Mail, Facebook, Instagram, Heart, MapPin } from 'lucide-react';
import logo from '../assets/jo-logo.jpeg'; 

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-brand-dark text-white pt-16 pb-8 font-sans">
      <div className="max-w-7xl mx-auto px-5 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          <div className="flex flex-col gap-6 items-center md:items-start text-center md:text-left">
            <div className="flex items-center gap-3">
              <div className="flex flex-col">
                <span className="text-lg font-black uppercase leading-none tracking-tighter">J & O CaringHands</span>
                <span className="text-[10px] font-bold text-brand-blue uppercase tracking-widest">Agency, LLC</span>
              </div>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed max-w-xs">
              Providing dependable, non-medical home care delivered with dignity, integrity, and genuine compassion.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-brand-blue transition-colors group">
                <Facebook size={18} className="text-slate-300 group-hover:text-white" />
              </a>
              <a href="#" className="w-10 h-10 bg-white/5 rounded-full flex items-center justify-center hover:bg-brand-blue transition-colors group">
                <Instagram size={18} className="text-slate-300 group-hover:text-white" />
              </a>
            </div>
          </div>

          <div className="text-center md:text-left">
            <h4 className="text-brand-blue font-black uppercase tracking-widest text-xs mb-6">Explore</h4>
            <ul className="space-y-4 text-sm font-medium text-slate-300">
              <li><a href="#home" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">Our Mission</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Care Services</a></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
            </ul>
          </div>

          <div className="text-center md:text-left">
            <h4 className="text-brand-blue font-black uppercase tracking-widest text-xs mb-6">Contact</h4>
            <ul className="space-y-5 text-sm font-medium">
              <li className="flex flex-col md:flex-row items-center md:items-start gap-3">
                <Phone size={18} className="text-brand-blue shrink-0" />
                <a href="tel:4842843911" className="text-slate-300 hover:text-white">+1 (484) 284-3911</a>
              </li>
              <li className="flex flex-col md:flex-row items-center md:items-start gap-3">
                <Mail size={18} className="text-brand-blue shrink-0" />
                <a href="mailto:Jandocaringhands@gmail.com" className="text-slate-300 hover:text-white break-all px-4 md:px-0">Jandocaringhands@gmail.com</a>
              </li>
              <li className="flex flex-col md:flex-row items-center md:items-start gap-3">
                <MapPin size={18} className="text-brand-blue shrink-0" />
                <span className="text-slate-300">680 American Ave Suite 302 King Off Prussia PA 19406, Pennsylvania.</span>
              </li>
            </ul>
          </div>

          <div className="bg-white/5 p-6 rounded-2xl border border-white/10 text-center md:text-left">
            <h4 className="text-white font-black uppercase text-xs mb-4">Our Values</h4>
            <p className="text-xs text-slate-400 italic leading-loose">
              "Healing starts at home. We assist clients in realizing their highest level of independence through faith-based service."
            </p>
            <div className="mt-4 flex items-center justify-center md:justify-start gap-2 text-brand-blue">
              <Heart size={14} fill="currentColor" />
              <span className="text-[10px] font-black uppercase tracking-tighter text-white">Compassionate Care</span>
            </div>
          </div>

        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] md:text-xs text-slate-500 font-bold uppercase tracking-widest">
          <p>© {currentYear} J & O CaringHands Agency, LLC.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Privacy</a>
            <a href="#" className="hover:text-white transition-colors">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}