import React, { useState } from 'react';
import { Send, Phone, Mail, Loader2, CheckCircle2 } from 'lucide-react';

export default function ContactForm() {
  const [agreed, setAgreed] = useState(false);
  const [status, setStatus] = useState('idle'); 
  const [formData, setFormData] = useState({
    fullname: '',
    email: '',
    phonenumber: '',
    age: '',
    address: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); 
    setStatus('loading');

    try {
      const response = await fetch('./contact.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      
      const result = await response.json();

      if (result.status === "success") {
        setStatus('success');
        setFormData({ fullname: '', email: '', phonenumber: '', age: '', address: '', message: '' });
      } else {
        setStatus('error');
      }
    } catch (error) {
      console.error("Error:", error);
      setStatus('error');
    }
  };

  return (
    <section id="contact" className="py-16 md:py-24 bg-white font-sans overflow-hidden">
      <div className="max-w-7xl mx-auto px-5 md:px-6">
        <div className="bg-slate-50 rounded-3xl overflow-hidden shadow-xl flex flex-col lg:flex-row">
          
          <div className="bg-brand-dark p-10 md:p-14 lg:w-2/5 text-white flex flex-col justify-between">
            <div>
              <h2 className="text-3xl md:text-4xl font-black mb-6 reveal">Let's Talk <br/><span className="text-brand-blue font-serif italic">Care</span></h2>
              <p className="text-slate-400 text-sm leading-relaxed mb-10 reveal">
                Ready to take the next step? Fill out the form and our care coordinator will reach out to you within 24 hours.
              </p>

              <div className="space-y-8 reveal">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                    <Phone className="text-brand-blue w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Call Us</p>
                    <p className="font-bold">+1 (484) 284-3911</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                    <Mail className="text-brand-blue w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-slate-500 font-bold">Email</p>
                    <p className="font-bold text-xs md:text-sm">Jandocaringhands@gmail.com</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 pt-8 border-t border-white/10 reveal">
              <p className="text-xs text-slate-500 uppercase tracking-widest leading-loose">
                Serving Pennsylvania with <br/> Dignity & Compassion.
              </p>
            </div>
          </div>

          <div className="p-8 md:p-14 lg:w-3/5 bg-white">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="flex flex-col gap-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-brand-dark">Full Name</label>
                  <input name="fullname" value={formData.fullname} onChange={handleChange} required type="text" placeholder="Oretha N." className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl focus:outline-none focus:border-brand-blue transition-colors text-sm" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-brand-dark">Email Address</label>
                  <input name="email" value={formData.email} onChange={handleChange} required type="email" placeholder="Oretha@example.com" className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl focus:outline-none focus:border-brand-blue transition-colors text-sm" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                <div className="flex flex-col gap-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-brand-dark">Phone Number</label>
                  <input name="phonenumber" value={formData.phonenumber} onChange={handleChange} required type="tel" placeholder="(555) 000-0000" className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl focus:outline-none focus:border-brand-blue transition-colors text-sm" />
                </div>
                <div className="flex flex-col gap-2">
                  <label className="text-[11px] font-black uppercase tracking-widest text-brand-dark">Age</label>
                  <input name="age" value={formData.age} onChange={handleChange} required type="number" placeholder="e.g. 75" className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl focus:outline-none focus:border-brand-blue transition-colors text-sm" />
                </div>
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-[11px] font-black uppercase tracking-widest text-brand-dark">Home Address</label>
                <input name="address" value={formData.address} onChange={handleChange} required type="text" placeholder="Street, City, Zip Code" className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl focus:outline-none focus:border-brand-blue transition-colors text-sm" />
              </div>

              <div className="flex flex-col gap-2">
                <label className="text-[11px] font-black uppercase tracking-widest text-brand-dark">Message / Inquiry Details</label>
                <textarea name="message" value={formData.message} onChange={handleChange} rows="4" placeholder="How can we help you?" className="w-full bg-slate-50 border border-slate-200 p-4 rounded-xl focus:outline-none focus:border-brand-blue transition-colors text-sm resize-none" />
              </div>

              <div className="flex items-start gap-3 py-2">
                <input 
                  type="checkbox" 
                  id="agree" 
                  className="mt-1 w-5 h-5 accent-brand-blue rounded border-slate-300 cursor-pointer"
                  checked={agreed}
                  onChange={(e) => setAgreed(e.target.checked)}
                />
                <label htmlFor="agree" className="text-xs text-slate-500 leading-snug cursor-pointer">
                  I agree to receive messages and updates from J & O CaringHands Agency regarding my care inquiry.
                </label>
              </div>

              <button 
                type="submit" 
                disabled={!agreed || status === 'loading' || status === 'success'}
                className={`w-full py-5 rounded-xl font-black uppercase tracking-widest text-[10px] md:text-xs flex items-center justify-center gap-3 transition-all duration-300 shadow-lg ${
                  status === 'success' ? 'bg-green-500 text-white' : 
                  status === 'error' ? 'bg-red-500 text-white' :
                  agreed ? 'bg-brand-blue text-white active:scale-95 hover:bg-brand-dark' : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                {status === 'idle' && <><Send size={16} /> Send Inquiry</>}
                {status === 'loading' && <><Loader2 size={16} className="animate-spin" /> Processing...</>}
                {status === 'success' && <><CheckCircle2 size={16} /> Sent Successfully!</>}
                {status === 'error' && "Error! Please Try Again"}
              </button>
              
              {status === 'success' && (
                <p className="text-center text-green-600 font-bold text-xs mt-2 animate-bounce">
                  Thank you! Our coordinator will contact you shortly.
                </p>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}