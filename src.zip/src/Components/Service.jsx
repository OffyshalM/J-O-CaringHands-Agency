import React from 'react';
import { UserCircle, Home, HeartHandshake, Check } from 'lucide-react';

export default function Service() {
  const services = [
    {
      title: "Personal Care",
      icon: <UserCircle className="w-10 h-10 md:w-12 md:h-12" />,
      description: "Assisting with daily living activities to maintain dignity and comfort.",
      items: ["Bathing & Personal Hygiene", "Dressing & Grooming", "Feeding assistance", "Toileting & Incontinence care"]
    },
    {
      title: "Homemaker",
      icon: <Home className="w-10 h-10 md:w-12 md:h-12" />,
      description: "Helping maintain a clean, safe, and organized living environment.",
      items: ["Light Housekeeping", "Meal Preparation", "Grocery Shopping", "Laundry & Linen changes"]
    },
    {
      title: "Companion",
      icon: <HeartHandshake className="w-10 h-10 md:w-12 md:h-12" />,
      description: "Providing emotional support and socialization for a better quality of life.",
      items: ["Social Interaction", "Accompany to appointments", "Supervision for safety", "Respite care for families"]
    }
  ];

  return (
    <section id="services" className="py-16 md:py-24 bg-slate-50 font-sans">
      <div className="max-w-7xl mx-auto px-5 md:px-6">
        
        <div className="reveal text-center max-w-2xl mx-auto mb-12 md:mb-16">
          <h2 className="text-brand-blue font-black uppercase tracking-[0.2em] text-[10px] md:text-xs mb-3">
            Professional Services
          </h2>
          <h3 className="text-3xl md:text-5xl font-black text-brand-dark mb-5">
            Our Care Pillars
          </h3>
        </div>

      
        <div className="flex overflow-x-auto w-full md:grid md:grid-cols-3 gap-6 no-scrollbar pb-10 snap-x snap-mandatory touch-pan-x">
          {services.map((service, index) => (
            <div 
              key={index} 
              className="reveal min-w-[88vw] md:min-w-0 snap-center bg-white p-8 md:p-10 rounded-3xl shadow-sm border border-slate-100 flex flex-col h-full"
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="w-16 h-16 md:w-20 md:h-20 bg-sky-50 text-brand-blue rounded-2xl flex items-center justify-center mb-6 group-hover:bg-brand-blue transition-all">
                {service.icon}
              </div>

              <h4 className="text-xl md:text-2xl font-black text-brand-dark mb-4">{service.title}</h4>
              <p className="text-slate-500 text-sm mb-6 leading-relaxed">
                {service.description}
              </p>

              <ul className="space-y-4 mt-auto">
                {service.items.map((item, i) => (
                  <li key={i} className="flex items-start gap-3 text-xs md:text-sm text-brand-dark font-semibold">
                    <Check className="w-4 h-4 text-brand-blue shrink-0 mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="flex md:hidden justify-center items-center gap-2 mt-2">
           <div className="w-12 h-1 bg-brand-blue rounded-full"></div>
           <div className="w-2 h-1 bg-slate-200 rounded-full"></div>
           <div className="w-2 h-1 bg-slate-200 rounded-full"></div>
           <p className="text-[10px] font-bold uppercase text-slate-400 ml-2 tracking-widest">Swipe</p>
        </div>
      </div>
    </section>
  );
}