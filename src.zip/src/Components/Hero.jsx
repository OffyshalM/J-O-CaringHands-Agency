import React from 'react';
import { ChevronRight, Heart, Church,Clock } from 'lucide-react';
import { Link } from 'react-router-dom';

import heroBg from '../assets/home-care-2.jpg';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[80vh] md:h-[85vh] w-full overflow-hidden font-sans">
      <div 
        className="absolute inset-0 bg-cover bg-[center_left_25%] md:bg-center bg-no-repeat"
        style={{ 
          backgroundImage: `url(${heroBg})` 
        }}
      >
        <div className="absolute inset-0 bg-brand-dark/70 md:bg-brand-dark/60 backdrop-brightness-90 md:backdrop-brightness-75"></div>
      </div>

      <div className="relative h-full max-w-7xl mx-auto px-6 py-20 md:py-0 flex flex-col justify-center items-start text-white">
        
        <div className="flex items-center gap-2 mb-4 animate-fade-in">
          <div className="w-6 md:w-8 h-[2px] bg-brand-blue"></div>
          <span className="text-brand-blue font-bold uppercase tracking-[0.2em] text-[9px] md:text-xs">
            Where Care Feels Like Family
          </span>
        </div>

        <h1 className="text-4xl sm:text-5xl md:text-7xl font-black mb-6 max-w-3xl leading-[1.15] md:leading-[1.1] tracking-tighter">
          Healing <span className="text-brand-blue">Starts</span> <br className="hidden md:block" /> at Home
        </h1>

        <p className="text-base md:text-xl text-slate-200 max-w-xl mb-8 md:mb-10 leading-relaxed font-light">
          We provide dependable, non-medical home care <strong>services</strong> with dignity... 
        </p>

        <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto">
          <a 
            href="#contact" 
            className="bg-brand-blue hover:bg-brand-dark text-white px-8 py-4 rounded-full font-bold uppercase tracking-widest text-[11px] md:text-xs flex items-center justify-center gap-2 transition-all shadow-xl active:scale-95"
          >
            Get Started Now
            <ChevronRight size={18} />
          </a>
          
          <Link 
            to="https://form.jotform.com/260637714154053" 
            className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/30 px-8 py-4 rounded-full font-bold uppercase tracking-widest text-[11px] md:text-xs flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            <Heart size={18} className="text-brand-blue" />
            Join Our Team
          </Link>
        </div>


<div className="mt-12 md:mt-16 flex items-center gap-4 md:gap-10 opacity-90 border-t border-white/10 pt-6 w-full md:w-auto">
  
  <div className="flex items-center gap-3">
    <div className="bg-brand-blue/20 p-2 rounded-lg">
      <Clock className="w-5 h-5 md:w-6 md:h-6 text-brand-blue" />
    </div>
    <div className="flex flex-col">
      <span className="text-xl md:text-2xl font-bold leading-none">24/7</span>
      <span className="text-[9px] uppercase tracking-[0.2em] text-slate-400 mt-1">Care</span>
    </div>
  </div>

  <div className="w-[1px] h-10 bg-white/20"></div>

  <div className="flex items-center gap-3">
    <div className="bg-brand-blue/20 p-2 rounded-lg">
      <Church className="w-5 h-5 md:w-6 md:h-6 text-brand-blue" />
    </div>
    <div className="flex flex-col">
      <span className="text-xl md:text-2xl font-bold italic text-white leading-none">Religious</span>
      <span className="text-[9px] uppercase tracking-[0.2em] text-slate-400 mt-1">Belief</span>
    </div>
  </div>
  
  </div>
      </div>
    </section>
  );
}