import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';

export default function ScrollToTop() {
  const [isVisible, setIsVisible] = useState(false);

  const toggleVisibility = () => {
    if (window.pageYOffset > 300) {
      setIsVisible(true);
    } else {
      setIsVisible(false);
    }
  };

  useEffect(() => {
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <a
        href="#home"
        className={`
          flex items-center justify-center w-12 h-12 md:w-14 md:h-14
          bg-brand-blue text-white rounded-full shadow-2xl
          transition-all duration-500 transform
          hover:bg-brand-dark hover:scale-110 active:scale-90
          ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}
        `}
        aria-label="Scroll to top"
      >
        <ArrowUp size={24} className="animate-bounce-slow" />
      </a>
    </div>
  );
}