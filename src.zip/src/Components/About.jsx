import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import aboutImg from '../assets/home-care-4.jpg'; 

export default function About() {
  return (
    <section id="about" className="py-20 bg-white font-sans overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          
          <div className="relative">
            <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src={aboutImg} 
                alt="Compassionate Caregiver" 
                className="w-full h-[500px] object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -right-6 w-64 h-64 bg-brand-blue/10 rounded-2xl -z-0 hidden md:block"></div>
            
            <div className="absolute top-10 -left-6 bg-brand-dark text-white p-6 rounded-xl shadow-xl hidden md:block">
              <p className="text-3xl font-black text-brand-blue">100%</p>
              <p className="text-[10px] uppercase tracking-widest font-bold">Compassion</p>
            </div>
          </div>

          <div className="flex flex-col">
            <div className="flex items-center gap-2 mb-4">
              <span className="text-brand-blue font-black uppercase tracking-widest text-xs">Our Mission</span>
              <div className="w-12 h-[1px] bg-brand-blue"></div>
            </div>
            
            <h2 className="text-xl md:text-2xl font-bold text-brand-dark mb-6 leading-relaxed">
              The Agency’s mission is to provide paraprofessional services to clients in their place of residence, 
              thereby assisting them to realize his or her highest level of independence and quality of life. 
              We are committed to providing quality care/service by staff members who recognize the value of 
              the aged and disabled. <span className="text-brand-blue italic block mt-2 text-sm uppercase tracking-wider">Statement</span>
            </h2>

            <p className="text-slate-600 leading-relaxed mb-8 text-lg">
              J & O CaringHands Agency, LLC is a non-medical home care agency built on a 
              <strong> religious belief</strong>. Our mission is to provide 
              dependable care delivered with dignity, integrity, and genuine compassion.
            </p>

            <div className="space-y-4 mb-10">
              {[
                "Promoting Highest Level of Independence",
                "Maintaining Dignity And Quality Of Life",
                "Integrity in Every Interaction",
                "Personal Support With Compassion"
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <CheckCircle2 className="text-brand-blue w-5 h-5" />
                  <span className="font-bold text-brand-dark text-sm uppercase tracking-wide">{item}</span>
                </div>
              ))}
            </div>

            <div className="bg-brand-blue p-6 rounded-xl shadow-md mb-8 transform hover:scale-[1.02] transition-transform">
              <p className="italic text-white font-medium text-lg">
                "Healing starts at home, and we are here to make sure your loved ones 
                realize their highest level of comfort and safety."
              </p>
            </div>

<button 
  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
  className="bg-brand-dark text-white self-start px-10 py-4 rounded-xl font-bold uppercase tracking-widest text-xs hover:bg-black transition-all shadow-lg active:scale-95"
>
  Learn More About Us
</button>
          </div>

        </div>
      </div>
    </section>
  );
}