
import { Phone, Mail } from 'lucide-react';
import { FaFacebookF, FaInstagram, FaYoutube, FaTiktok } from 'react-icons/fa';

export default function Header() {
  return (
    <header className="hidden md:flex bg-white border-b border-slate-100 w-full">
      <div className="max-w-7xl mx-auto flex items-center justify-between py-3 px-6 w-full">
        
        <div className="flex items-center gap-5 text-lg">
          <a href="#" className="text-brand-dark/50 hover:text-brand-blue transition-colors"><FaFacebookF size={16} /></a>
          <a href="#" className="text-brand-dark/50 hover:text-pink-600 transition-colors"><FaInstagram size={16} /></a>
          <a href="#" className="text-brand-dark/50 hover:text-red-600 transition-colors"><FaYoutube size={16} /></a>
          <a href="#" className="text-brand-dark/50 hover:text-black transition-colors"><FaTiktok size={16} /></a>
        </div>

        <div className="flex items-center gap-8">
          <a href="tel:4842843911" className="flex items-center gap-2 text-brand-dark font-bold hover:text-brand-blue text-sm">
            <Phone className="w-4 h-4 text-brand-blue" />
            <span>+1 (484) 284-3911</span>
          </a>
          <a href="mailto:Jandocaringhands@gmail.com" className="flex items-center gap-2 text-brand-dark/80 font-semibold hover:text-brand-blue text-sm">
            <Mail className="w-4 h-4 text-brand-blue" />
            <span>Jandocaringhands@gmail.com</span>
          </a>
        </div>
      </div>
    </header>
  );
}