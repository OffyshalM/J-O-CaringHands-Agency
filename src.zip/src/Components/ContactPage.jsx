import React from 'react';
import { Phone, Mail, Clock, MapPin, MessageSquare } from 'lucide-react';

export default function ContactPage() {
  return (
    <div className="bg-white font-sans min-h-screen">
      <section className="bg-brand-dark py-20 md:py-32 px-5 text-center">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-black text-white mb-6 uppercase tracking-tighter">
            Get In <span className="text-brand-blue">Touch</span>
          </h1>
          <div className="w-20 h-1.5 bg-brand-blue mx-auto mb-8"></div>
          <p className="text-slate-400 max-w-2xl mx-auto text-sm md:text-lg leading-relaxed font-light">
            Whether you have questions about our care services or want to schedule a 
            free assessment, our team is standing by to assist you.
          </p>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-5 md:px-6 -mt-12 md:-mt-16 pb-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          
          <div className="bg-white p-10 rounded-3xl border border-slate-100 shadow-xl flex flex-col items-center text-center group hover:border-brand-blue transition-all duration-300">
            <div className="w-16 h-16 bg-sky-50 rounded-2xl flex items-center justify-center mb-6 text-brand-blue group-hover:bg-brand-blue group-hover:text-white transition-all">
              <Phone size={32} />
            </div>
            <h3 className="font-black text-brand-dark uppercase text-xs tracking-[0.2em] mb-3">Call Our Office</h3>
            <a href="tel:4842843911" className="text-xl md:text-2xl font-bold text-slate-800 hover:text-brand-blue transition-colors">
              +1 (484) 284-3911
            </a>
          </div>

          <div className="bg-white p-10 rounded-3xl border border-slate-100 shadow-xl flex flex-col items-center text-center group hover:border-brand-blue transition-all duration-300">
            <div className="w-16 h-16 bg-sky-50 rounded-2xl flex items-center justify-center mb-6 text-brand-blue group-hover:bg-brand-blue group-hover:text-white transition-all">
              <Mail size={32} />
            </div>
            <h3 className="font-black text-brand-dark uppercase text-xs tracking-[0.2em] mb-3">Send an Email</h3>
            <a href="mailto:Jandocaringhands@gmail.com" className="text-sm md:text-lg font-bold text-slate-800 hover:text-brand-blue transition-colors break-all">
              Jandocaringhands@gmail.com
            </a>
          </div>

          <div className="md:col-span-2 bg-slate-50 p-10 rounded-3xl border border-slate-100 flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-white rounded-2xl shadow-sm flex items-center justify-center mb-6 text-brand-blue">
              <Clock size={32} />
            </div>
            <h3 className="font-black text-brand-dark uppercase text-xs tracking-[0.2em] mb-3">Availability</h3>
            <p className="text-xl font-bold text-slate-800">24/7 Support Available</p>
            <p className="text-sm text-slate-500 mt-2 max-w-xs font-medium">
              Our care coordinators are available around the clock to ensure your peace of mind.
            </p>
          </div>
        </div>

        <div className="mt-12 bg-white p-8 md:p-12 rounded-3xl border border-slate-100 shadow-sm text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 bg-brand-blue/10 text-brand-blue rounded-full mb-6">
            <MapPin size={24} />
          </div>
          <h4 className="text-2xl font-black text-brand-dark mb-4 uppercase tracking-tight">Our Service Area</h4>
          <p className="text-slate-600 max-w-md mx-auto leading-relaxed">
            Proudly serving families across <strong>Pennsylvania</strong> with 
            compassionate, faith-based home care.
          </p>
        </div>
      </div>
    </div>
  );
}