import React, { useEffect } from 'react'; 
import { Routes, Route } from 'react-router-dom'; 
import Navbar from './Components/Navbar'; 
import Header from './Components/Header'; 
import Hero from './Components/Hero'; 
import About from './Components/About'; 
import Service from './Components/Service';
import ContactForm from './Components/ContactForm';
// Removed ContactPage import as it is no longer needed
import FAQ from './Components/FAQ';
import Footer from './Components/Footer';
import ScrollToTop from './Components/ScrollToTop';

function App() {
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('show');
        }
      });
    }, { threshold: 0.1 });

    document.querySelectorAll('.reveal').forEach((el) => observer.observe(el));
    
    return () => observer.disconnect();
  }, []);

  // Shared layout for both / and /contact
  const MainContent = (
    <main>
      <Hero />
      <About />
      <Service />
      <FAQ />
      <div id="contact-section">
        <ContactForm />
      </div>
    </main>
  );

  return (
    <div id="home" className="min-h-screen bg-white font-sans relative overflow-x-hidden">
      
      <div className="fixed top-0 left-0 w-full h-full -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-brand-blue/5 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[10%] right-[-5%] w-[30%] h-[30%] bg-brand-blue/10 rounded-full blur-[100px]"></div>
      </div>

      <Header />
      <Navbar />

      <Routes>
        <Route path="/" element={MainContent} />
        <Route path="/contact" element={MainContent} />
        
        <Route path="*" element={MainContent} />
      </Routes>

      <Footer />
      <ScrollToTop />
    </div>
  );
}

export default App;